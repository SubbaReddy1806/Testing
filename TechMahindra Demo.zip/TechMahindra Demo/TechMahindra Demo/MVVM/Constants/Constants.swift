//
//  Constants.swift
//  TechMahindra Demo
//
//  Created by Subba Reddy on 8/4/20.
//  Copyright © 2020 Subba Reddy. All rights reserved.
//

import Foundation

struct BaseURL {
    static let userInfoURl = "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json"
}
